class BooksController < ApplicationController


  def index
    @user = current_user
    @book_new = Book.new
    @books = Book.all
  end

  def show
    @book_new = Book.new
    @books = Book.all
    @book = Book.find(params[:id])
    @user = @book.user
  end

  def create
    @book_new = Book.new(book_params)
    @book_new.user_id = current_user.id
    if @book_new.save
      flash[:notice]="You have creatad book successfully."
      redirect_to book_path(@book_new)
    else
      @user = current_user
      @books = Book.all
      render :index
    end
  end

  def edit
    @books = Book.all
    @book = Book.find(params[:id])

    unless current_user == @book.user
      redirect_to books_path
      return
    end
      render :edit
  end

  def update
    @book = Book.find(params[:id])

    if @book.update(book_params)
      flash[:notice] = "Book was successfully updated."
      redirect_to book_path(@book.id)
    else
      render :edit
    end
  end

  def destroy
    @book = Book.find(params[:id])
    if @book.destroy
      flash[:notice]="Book was successfully destroyed."
      redirect_to books_path
    end
  end

  private


  def set_book
    @book = Book.find(params[:id])
  end

  def check_authorization

    unless current_user == @book.user
      redirect_to books_path
    end
  end


  def book_params
    params.require(:book).permit(:title, :body)
  end
end
