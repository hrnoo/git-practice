class UsersController < ApplicationController


  def index
    @user = User.find(current_user.id)
    @book_new = Book.new
    @users = User.all
    @books = Book.all
  end

  def show
    @user = User.find(params[:id])
    @books = @user.books
    @book_new = Book.new(user_id: @user.id)
  end

 def edit
   @user = User.find(params[:id])
     if current_user != @user
     redirect_to user_path(current_user)
     end
 end


  def update
        @books = Book.all
        @user = User.find(params[:id])
       if  @user.update(user_params)
        flash[:notice] = "You have updated user successfully."

        redirect_to "/users/#{current_user.id}"
       else
        flash[:notice] = " errors prohibited this obj from being saved:"
            render :edit

       end
  end

  private


  def book_params
        params.require(:book).permit(:title, :body)
  end

  def user_params
        params.require(:user).permit(:name, :profile_image, :introduction, :user_id)
  end

  def  ensure_current_user
        @user = User.find(params[:id])
     if @user.id != current_user.id
        redirect_to user_path(current_user.id)

     end

  end

end
