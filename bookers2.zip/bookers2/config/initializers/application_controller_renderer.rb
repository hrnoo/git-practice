# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '45ff2ab2ddd697ed28336286dc585094c6c55fef6adbbf78f25e0c45d1270139358d04c240cb2d3383ed848a7fbf099c705368f9b86b7ee4ee3dfafa3d6f209a'